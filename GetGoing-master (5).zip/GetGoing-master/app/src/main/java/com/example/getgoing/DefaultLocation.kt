package com.example.getgoing

data class DefaultLocation(
    val latitude: Double = 1.3521,
    val longitude: Double = 103.8198
)
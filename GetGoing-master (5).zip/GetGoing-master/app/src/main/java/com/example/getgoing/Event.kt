package com.example.getgoing

data class Event(var name: String, var totalAmount: Double)

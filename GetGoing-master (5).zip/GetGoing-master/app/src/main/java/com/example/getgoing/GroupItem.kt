package com.example.getgoing

data class GroupItem (var name: String, var image: Int)

package com.example.getgoing

data class Friend (var name: String, var image: Int, var phone: String, var isChecked: Boolean = false)
